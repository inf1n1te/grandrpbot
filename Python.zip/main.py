import discord
from discord.ext import tasks, commands
from datetime import datetime
import pytz

TOKEN = 'MTI3NjM2NDYxOTY5ODQwNTQzNw.G4WcvR.Nc54q0Kk1ej8ESN8Ld2PtNtJB454ecnwafSAbk'
MAX_TEILNEHMER = 10  # Maximale Anzahl der Teilnehmer
CHANNEL_ID = 1276366432753684630  # Ersetze durch deine Channel-ID
GUILD_ID = 1276366432753684625  # Ersetze durch deine Server-ID

intents = discord.Intents.default()
intents.reactions = True  # Reaktionen aktivieren
intents.message_content = True  # Inhalt von Nachrichten zulassen

bot = commands.Bot(command_prefix='!', intents=intents)

teilnehmer = []  # Liste der Teilnehmer
activities = ["Cazal Systems", "by Melih"]  # Aktivitäten für den Status
activity_index = 0  # Startindex für die Aktivitäten
message_ids = {}  # Zum Speichern von Nachrichten-IDs für die Anmeldung


# Funktion, die den Embed erstellt
def create_embed():
    embed = discord.Embed(
        title="40er - Anmeldung",
        description=
        f"Reagiere mit ✅, um teilzunehmen. Maximal {MAX_TEILNEHMER} Teilnehmer.",
        color=0x3498db,  # Farbe des Embeds
        timestamp=datetime.now(
            pytz.timezone('Europe/Berlin'))  # Zeitstempel hinzufügen
    )

    # Teilnehmerliste zum Embed hinzufügen
    if teilnehmer:
        embed.add_field(name="👥Teilnehmer",
                        value="\n".join(teilnehmer),
                        inline=False)
    else:
        embed.add_field(name="👥Teilnehmer",
                        value="Noch keine Teilnehmer",
                        inline=False)

    # Neue Felder hinzufügen
    embed.add_field(name="🚗Anfahrt:", value="0$", inline=True)
    embed.add_field(name="☠Killvergütung:", value="30000$", inline=True)

    embed.set_footer(text="Klicke auf das Emoji unten, um teilzunehmen.")
    return embed


# Task, der jede Minute überprüft, ob es XX:40 Uhr oder XX:45 Uhr ist
@tasks.loop(minutes=1)
async def check_time():
    berlin_tz = pytz.timezone('Europe/Berlin')
    now = datetime.now(berlin_tz)

    if now.minute == 35:
        await send_embed()
    elif now.minute == 40:
        await close_registration()


# Funktion, um das Embed manuell oder automatisch zu senden
async def send_embed():
    channel = bot.get_channel(CHANNEL_ID)
    if channel:
        embed = create_embed()
        message = await channel.send(embed=embed)
        await message.add_reaction("✅")  # Emoji hinzufügen

        view = TeilnehmerView(message.id)
        await message.edit(
            view=view)  # Die View wird nach dem Senden des Embeds hinzugefügt

        # Speichern der Nachrichten-ID zur späteren Bearbeitung
        message_ids[channel.id] = message.id


# Funktion, um die Registrierung zu schließen
async def close_registration():
    channel = bot.get_channel(CHANNEL_ID)
    if channel:
        if channel.id in message_ids:
            message_id = message_ids[channel.id]
            message = await channel.fetch_message(message_id)
            if message:
                view = TeilnehmerView(message_id)
                # Deaktiviere den Button und aktualisiere das Embed
                for item in view.children:
                    if isinstance(item, discord.ui.Button):
                        item.disabled = True
                embed = create_embed()
                await message.edit(embed=embed, view=view)
                # Entferne die gespeicherte Nachricht-ID, um zu verhindern, dass es später erneut bearbeitet wird
                del message_ids[channel.id]


# Event, wenn eine Reaktion hinzugefügt wird
class TeilnehmerView(discord.ui.View):

    def __init__(self, message_id):
        super().__init__(timeout=None)  # Timeout entfernen für Persistenz
        self.message_id = message_id

    @discord.ui.button(label="Teilnehmen",
                       style=discord.ButtonStyle.green,
                       emoji="✅",
                       custom_id="teilnahme_button")
    async def button_callback(self, button: discord.ui.Button,
                              interaction: discord.Interaction):
        global teilnehmer

        try:
            user_name = interaction.user.name

            if user_name in teilnehmer:
                await interaction.response.send_message(
                    "Du bist bereits angemeldet!", ephemeral=True)
                return

            if len(teilnehmer) < MAX_TEILNEHMER:
                teilnehmer.append(user_name)
                await interaction.response.send_message(
                    f"Du wurdest erfolgreich angemeldet! ({len(teilnehmer)}/{MAX_TEILNEHMER})",
                    ephemeral=True)

                # Aktualisiere das Embed mit der aktualisierten Teilnehmerliste
                channel = interaction.channel
                message = await channel.fetch_message(self.message_id)
                embed = create_embed()
                await message.edit(embed=embed)

                # Deaktiviere den Button, wenn das Limit erreicht ist
                if len(teilnehmer) >= MAX_TEILNEHMER:
                    button.disabled = True
                    await interaction.message.edit(view=self)
            else:
                await interaction.response.send_message(
                    "Die maximale Anzahl an Teilnehmern wurde erreicht.",
                    ephemeral=True)
        except Exception as e:
            print(f"Fehler im Button-Callback: {e}")
            if interaction.response.is_done():
                return  # Verhindere doppelte Antworten
            await interaction.response.send_message(
                "Ein Fehler ist aufgetreten. Bitte versuche es später erneut.",
                ephemeral=True)


# Task zum Wechseln der Aktivität
@tasks.loop(seconds=2)
async def change_activity():
    global activity_index
    await bot.change_presence(activity=discord.Game(
        name=activities[activity_index]))
    activity_index = (activity_index + 1) % len(activities)


# Slash-Befehl, um den Trigger manuell auszuführen
@bot.command(name="40er")
async def manual_trigger(ctx):
    await send_embed()


# Startet den Task, sobald der Bot bereit ist
@bot.event
async def on_ready():
    print(f'Bot ist eingeloggt als {bot.user}')
    check_time.start()  # Starte den Task zum Überprüfen der Zeit
    change_activity.start()


# Starte den Bot
bot.run(TOKEN)
